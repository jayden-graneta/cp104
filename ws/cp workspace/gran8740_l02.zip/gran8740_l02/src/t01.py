"""
-------------------------------------------------------
[Converts celsius to fahrenheit]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-09-21"
-------------------------------------------------------
"""
# Imports

# Constants

cel = int(input("Temperature (C):"))
FAIR = 32
temp = (9/5) * cel + FAIR
print("Temperature (F):", temp)
