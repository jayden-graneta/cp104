"""
-------------------------------------------------------
[Determining which year is a leap year]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
# Imports
from functions import is_leap
# Constants

print(is_leap(1900))
