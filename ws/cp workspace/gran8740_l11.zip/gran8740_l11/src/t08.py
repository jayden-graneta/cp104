"""
-------------------------------------------------------
[find less]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import find_less
# Constants


print(find_less([[8, 2, -3], [7, 4, 4], [-2, -1, 0], [-1, -6, 2]], 0))
