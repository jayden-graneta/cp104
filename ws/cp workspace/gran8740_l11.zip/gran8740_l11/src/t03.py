"""
-------------------------------------------------------
[print matrix number]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import print_matrix_num, generate_matrix_num
# Constants


matrix = generate_matrix_num(2, 3, 1, 10, 'int')
print(print_matrix_num(matrix, 'int'))
