"""
-------------------------------------------------------
[generate matrix number]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_num
# Constants

print(generate_matrix_num(2, 2, 1, 10, 'int'))
