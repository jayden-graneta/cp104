"""
-------------------------------------------------------
[Inputs the users name and favourite band]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""

age = input('What is your age?')
band = input('What is your favourite band?')

print('I am', age, 'years old and', band, 'is my favourite band.')
