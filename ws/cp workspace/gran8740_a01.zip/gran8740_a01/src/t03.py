"""
-------------------------------------------------------
[Converts miles to km]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""

KM = 1.61

length = float(input('Length in miles:'))

conver = length * KM

print('Length in km:', conver)
