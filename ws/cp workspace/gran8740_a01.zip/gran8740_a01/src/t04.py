"""
-------------------------------------------------------
[Price of dosa]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""

cost_dosa = float(input('Cost of 1 dosa:'))
num_dosa = int(input('Number of dosa:'))

total_cost = cost_dosa * num_dosa

print("Total cost of", num_dosa, 'dosas: $', total_cost)
