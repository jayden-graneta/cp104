"""
-------------------------------------------------------
[factor_summation]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import factor_summation
# Constants

print(factor_summation(21))
