"""
-------------------------------------------------------
[interest_table]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import interest_table
# Constants


print(interest_table(1, 10, 50))
