"""
-------------------------------------------------------
[Generate integer]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import generate_integer_list
# Constants

print(generate_integer_list(3, 0, 100))
