"""
-------------------------------------------------------
[list categorize]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import list_categorize
# Constants


print(list_categorize([94, 96, -22, -79, -28, -26, -50, 71, 24, -32]))
