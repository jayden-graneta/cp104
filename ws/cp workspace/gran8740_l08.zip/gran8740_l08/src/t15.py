"""
-------------------------------------------------------
[symmetric_difference]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import symmetric_difference
# Constants

print(symmetric_difference([10, 3, 10, 3, 1], [8, 2, 7, 3, 6, 10, 32, 99]))
