"""
-------------------------------------------------------
[many search]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import many_search
# Constants

print(many_search([94, 96, -22, -79, -28, 96, -50, 71, 24, -32], 96))
