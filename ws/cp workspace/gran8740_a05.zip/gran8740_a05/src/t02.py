"""
-------------------------------------------------------
[calorie treadmill]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import calories_treadmill
# Constants

calories = calories_treadmill(4.1, 20)
print(calories)
