"""
-------------------------------------------------------
[range addition]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import range_addition
# Constants

print(range_addition(1, 2, 20))
