"""
-------------------------------------------------------
[multiplication table]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import multiplication_table
# Constants

table = multiplication_table(2, 4)
print(table)
