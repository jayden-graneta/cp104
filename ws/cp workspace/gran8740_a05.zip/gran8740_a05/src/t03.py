"""
-------------------------------------------------------
[draw arrow up]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import arrow_up
# Constants

arrow = arrow_up(4)

print(arrow)
