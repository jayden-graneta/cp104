"""
-------------------------------------------------------
[Fraction multiplication]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import multiply_fractions
# Constants

fractions = (multiply_fractions(6, 5, 8, 3))
print(fractions)
