"""
-------------------------------------------------------
[Lawn mow time]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import lawn_mow_time
# Constants

time = lawn_mow_time(30.0, 470.0, 6.0)

print(time)
