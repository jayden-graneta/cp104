"""
-------------------------------------------------------
[First Customer]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import customer_first

# Constants

fh = open("customers.txt", "r")

print(customer_first(fh))
