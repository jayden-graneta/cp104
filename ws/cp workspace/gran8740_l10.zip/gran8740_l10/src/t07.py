"""
-------------------------------------------------------
[append max number]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import append_max_num
# Constants

fh = open("numbers.txt", 'r+')
print(append_max_num(fh))
