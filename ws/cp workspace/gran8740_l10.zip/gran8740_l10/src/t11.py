"""
-------------------------------------------------------
[find the longest]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import find_longest
# Constants

fh = open("words.txt", "r")

print(find_longest(fh))
