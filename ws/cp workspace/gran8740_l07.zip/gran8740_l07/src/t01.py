"""
-------------------------------------------------------
[hi to low game]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import hi_lo_game
# Constants

hi_lo_game(5)
