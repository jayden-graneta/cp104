"""
-------------------------------------------------------
[Finding the diffrence in max and min]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-09-26"
-------------------------------------------------------

"""

min = int(input('Enter minimum:'))
max = int(input("Enter maximum:"))
diff = max - min

print(f'The difference between {max:d} and {min:d} is {diff:d}')
