"""
-------------------------------------------------------
[list subtract]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import list_subtract
# Constants

minuend = [5, 5, 4, 5]
subtrahend = [5]
list_subtract(minuend, subtrahend)

print(minuend)
