"""
-------------------------------------------------------
[listing factors]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports
from functions import list_factors
# Constants

factors = list_factors(36)

print(factors)
