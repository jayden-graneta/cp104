"""
-------------------------------------------------------
[Is hydroxide]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import is_hydroxide
# Constants

print(is_hydroxide('NaOH'))
