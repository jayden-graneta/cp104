"""
-------------------------------------------------------
[Text analyzer]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import text_analyze
# Constants

print(text_analyze('Python uses whitespace indentation, rather than curly brackets or keywords, to delimit blocks.'))
