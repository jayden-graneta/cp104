"""
-------------------------------------------------------
[Parse decoder]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports
from functions import parse_code
# Constants

print(parse_code('ATV3482S14'))
