"""
-------------------------------------------------------
[day of the week name]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import day_name
# Constants

day = day_name(0)
print(day)
