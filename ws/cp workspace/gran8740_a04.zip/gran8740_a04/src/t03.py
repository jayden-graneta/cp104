"""
-------------------------------------------------------
[Largest average]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import largest_average
# Constants
average = largest_average(1, 2, 3)
print(average)
