"""
-------------------------------------------------------
[pluralize]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import pluralize
# Constants


print(pluralize('city'))
print(pluralize("Watch"))
print(pluralize("J Cole"))
