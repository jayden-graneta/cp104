"""
-------------------------------------------------------
[common ending]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports
from functions import common_end
# Constants


print(common_end('Jumping', 'Running'))
print(common_end('Fast', 'Cast'))
print(common_end('Dance', 'Lance'))
