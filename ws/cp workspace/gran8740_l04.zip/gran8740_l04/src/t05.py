"""
-------------------------------------------------------
[Testing right triangle function]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
# Imports
from functions import right_triangle
# Constants

print(right_triangle(3.0, 4.0))
