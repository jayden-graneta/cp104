"""
-------------------------------------------------------
[Testing computer cost function]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
# Imports
from functions import computer_costs
# Constants

print(computer_costs(1399, 87, 8.5))
