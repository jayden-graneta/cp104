"""
-------------------------------------------------------
[Name return t04]
-------------------------------------------------------
Author:  Jayden Rey Graneta
ID:      169058740
Email:   gran8740@mylaurier.ca
__updated__ = "2024-01-31"
-------------------------------------------------------
"""
# Imports

# Constants

name = input("Please enter your name: ")
print("Pleased to meet you ")
print(name)
